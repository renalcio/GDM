-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 27-Nov-2014 às 22:47
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cdm`
--
CREATE DATABASE IF NOT EXISTS `cdm` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `cdm`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `Aplicacao`
--

CREATE TABLE IF NOT EXISTS `Aplicacao` (
  `AplicacaoId` int(255) NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Descricao` text CHARACTER SET latin1,
  `PessoaId` int(255) NOT NULL,
  `DataCriacao` bigint(20) NOT NULL,
  `NichoId` int(255) NOT NULL,
  PRIMARY KEY (`AplicacaoId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `Aplicacao`
--

INSERT INTO `Aplicacao` (`AplicacaoId`, `Titulo`, `Descricao`, `PessoaId`, `DataCriacao`, `NichoId`) VALUES
(1, 'GDM', 'Gerenciador de Dados Modular', 1, 0, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `Menu`
--

CREATE TABLE IF NOT EXISTS `Menu` (
  `MenuId` int(11) NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(255) COLLATE utf8_bin NOT NULL,
  `Url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `Icone` varchar(70) COLLATE utf8_bin DEFAULT NULL,
  `Pai` int(11) NOT NULL DEFAULT '0',
  `AplicacaoId` int(255) NOT NULL,
  `Posicao` int(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`MenuId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=23 ;

--
-- Extraindo dados da tabela `Menu`
--

INSERT INTO `Menu` (`MenuId`, `Titulo`, `Url`, `Icone`, `Pai`, `AplicacaoId`, `Posicao`) VALUES
(19, 'Home', '', 'fa-home', 0, 1, 0),
(20, 'Configurações', '', 'fa-gears', 0, 1, 1),
(21, 'Menu', '', 'fa-indent', 20, 1, 0),
(22, 'Aplicação Atual', 'menu/cadastro', '', 21, 1, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `Nicho`
--

CREATE TABLE IF NOT EXISTS `Nicho` (
  `NichoId` int(11) NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`NichoId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `Nicho`
--

INSERT INTO `Nicho` (`NichoId`, `Titulo`) VALUES
(1, 'Desenvolvimento de Software');

-- --------------------------------------------------------

--
-- Estrutura da tabela `Perfil`
--

CREATE TABLE IF NOT EXISTS `Perfil` (
  `PerfilId` int(255) NOT NULL AUTO_INCREMENT,
  `AplicacaoId` int(255) NOT NULL,
  `Titulo` varchar(255) COLLATE utf8_bin NOT NULL,
  `Ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`PerfilId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `Perfil`
--

INSERT INTO `Perfil` (`PerfilId`, `AplicacaoId`, `Titulo`, `Ativo`) VALUES
(1, 1, 'Root', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `Pessoa`
--

CREATE TABLE IF NOT EXISTS `Pessoa` (
  `PessoaId` int(255) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(255) COLLATE utf8_bin NOT NULL,
  `Email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `Telefone` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Celular` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Observacao` text COLLATE utf8_bin,
  `Foto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`PessoaId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `Pessoa`
--

INSERT INTO `Pessoa` (`PessoaId`, `Nome`, `Email`, `Telefone`, `Celular`, `Observacao`, `Foto`) VALUES
(1, 'Administrador', 'admin@teste.com', '3454564654', '35454354', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `RegraPerfil`
--

CREATE TABLE IF NOT EXISTS `RegraPerfil` (
  `RegraPerfilId` int(255) NOT NULL AUTO_INCREMENT,
  `PerfilId` int(255) NOT NULL,
  `Permitir` tinyint(1) NOT NULL DEFAULT '1',
  `MenuId` int(255) NOT NULL,
  `AplicacaoId` int(255) NOT NULL,
  PRIMARY KEY (`RegraPerfilId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `song`
--

CREATE TABLE IF NOT EXISTS `song` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artist` text COLLATE utf8_unicode_ci NOT NULL,
  `track` text COLLATE utf8_unicode_ci NOT NULL,
  `link` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Extraindo dados da tabela `song`
--

INSERT INTO `song` (`id`, `artist`, `track`, `link`) VALUES
(2, 'Jessy Lanza', 'Kathy Lee', 'http://vimeo.com/73455369'),
(3, 'The Orwells', 'In my Bed (live)', 'http://www.youtube.com/watch?v=8tA_2qCGnmE'),
(4, 'L''Orange & Stik Figa', 'Smoke Rings', 'https://www.youtube.com/watch?v=Q5teohMyGEY'),
(5, 'Labyrinth Ear', 'Navy Light', 'http://www.youtube.com/watch?v=a9qKkG7NDu0'),
(6, 'Bon Hiver', 'Wolves (Kill them with Colour Remix)', 'http://www.youtube.com/watch?v=5GXAL5mzmyw'),
(7, 'Detachments', 'Circles (Martyn Remix)', 'http://www.youtube.com/watch?v=UzS7Gvn7jJ0'),
(8, 'Dillon & Dirk von Loetzow', 'Tip Tapping (Live at ZDF Aufnahmezustand)', 'https://www.youtube.com/watch?v=hbrOLsgu000'),
(9, 'Dillon', 'Contact Us (Live at ZDF Aufnahmezustand)', 'https://www.youtube.com/watch?v=E6WqTL2Up3Y'),
(10, 'Tricky', 'Hey Love (Promo Edit)', 'http://www.youtube.com/watch?v=OIsCGdW49OQ'),
(11, 'Compuphonic', 'Sunset feat. Marques Toliver (DJ T. Remix)', 'http://www.youtube.com/watch?v=Ue5ZWSK9r00'),
(12, 'Ludovico Einaudi', 'Divenire (live @ Royal Albert Hall London)', 'http://www.youtube.com/watch?v=X1DRDcGlSsE'),
(13, 'Maxxi Soundsystem', 'Regrets we have no use for (Radio1 Rip)', 'https://soundcloud.com/maxxisoundsystem/maxxi-soundsystem-ft-name-one'),
(14, 'Beirut', 'Nantes (Fredo & Thang Remix)', 'https://www.youtube.com/watch?v=ojV3oMAgGgU'),
(15, 'Buku', 'All Deez', 'http://www.youtube.com/watch?v=R0bN9JRIqig'),
(16, 'Pilocka Krach', 'Wild Pete', 'http://www.youtube.com/watch?v=4wChP_BEJ4s'),
(17, 'Mount Kimbie', 'Here to stray (live at Pitchfork Music Festival Paris)', 'http://www.youtube.com/watch?v=jecgI-zEgIg'),
(18, 'Kool Savas', 'King of Rap (2012) / Ein Wunder', 'http://www.youtube.com/watch?v=mTqc6UTG1eY&hd=1'),
(19, 'Chaim feat. Meital De Razon', 'Love Rehab (Original Mix)', 'http://www.youtube.com/watch?v=MJT1BbNFiGs'),
(20, 'Emika', 'Searching', 'http://www.youtube.com/watch?v=oscuSiHfbwo'),
(21, 'Emika', 'Sing to me', 'http://www.youtube.com/watch?v=k9sDBZm8pgk'),
(22, 'George Fitzgerald', 'Thinking of You', 'http://www.youtube.com/watch?v=-14B8l49iKA'),
(23, 'Disclosure', 'You & Me (Flume Edit)', 'http://www.youtube.com/watch?v=OUkkaqSNduU'),
(24, 'Crystal Castles', 'Doe Deer', 'http://www.youtube.com/watch?v=zop0sWrKJnQ'),
(25, 'Tok Tok vs. Soffy O.', 'Missy Queens Gonna Die', 'http://www.youtube.com/watch?v=EN0Tnw5zy6w'),
(26, 'Fink', 'Maker (Synapson Remix)', 'http://www.youtube.com/watch?v=Dyd-cUkj4Nk'),
(27, 'Flight Facilities (ft. Christine Hoberg)', 'Clair De Lune', 'http://www.youtube.com/watch?v=Jcu1AHaTchM'),
(28, 'Karmon', 'Turning Point (Original Mix)', 'https://www.youtube.com/watch?v=-tB-zyLSPEo'),
(29, 'Shuttle Life', 'The Birds', 'http://www.youtube.com/watch?v=-I3m3cWDEtM'),
(30, 'SantÃ©', 'Homegirl (Rampa Mix)', 'http://www.youtube.com/watch?v=fnhMNOWxLYw');

-- --------------------------------------------------------

--
-- Estrutura da tabela `Usuario`
--

CREATE TABLE IF NOT EXISTS `Usuario` (
  `UsuarioId` int(255) NOT NULL AUTO_INCREMENT,
  `AplicacaoId` int(255) NOT NULL,
  `Login` varchar(255) COLLATE utf8_bin NOT NULL,
  `Senha` varchar(255) COLLATE utf8_bin NOT NULL,
  `PessoaId` int(255) NOT NULL,
  `Ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`UsuarioId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `Usuario`
--

INSERT INTO `Usuario` (`UsuarioId`, `AplicacaoId`, `Login`, `Senha`, `PessoaId`, `Ativo`) VALUES
(1, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `UsuarioPerfil`
--

CREATE TABLE IF NOT EXISTS `UsuarioPerfil` (
  `UsuarioPerfilId` int(255) NOT NULL AUTO_INCREMENT,
  `PerfilId` int(255) NOT NULL,
  `UsuarioId` int(255) NOT NULL,
  PRIMARY KEY (`UsuarioPerfilId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `UsuarioPerfil`
--

INSERT INTO `UsuarioPerfil` (`UsuarioPerfilId`, `PerfilId`, `UsuarioId`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `Variaveis`
--

CREATE TABLE IF NOT EXISTS `Variaveis` (
  `VariavelId` int(255) NOT NULL AUTO_INCREMENT,
  `AplicacaoId` int(255) NOT NULL,
  `Titulo` varchar(255) COLLATE utf8_bin NOT NULL,
  `Valor` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`VariavelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
